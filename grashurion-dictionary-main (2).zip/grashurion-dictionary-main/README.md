# grashurion-dictionary

このプロジェクトは、「グラシュリオン」設定辞典をNetlify CMSで管理・公開するためのリポジトリです。

## 機能概要

- グラシュリオン世界観の専門用語や設定を管理
- 自動デプロイでWebサイトに反映

## 使用技術

- HTML/CSS/JavaScript
- Netlify CMS
- GitHub + Netlify 連携

## 編集画面のURL

サイトURL `/admin/` にアクセスして管理画面へログインしてください。
